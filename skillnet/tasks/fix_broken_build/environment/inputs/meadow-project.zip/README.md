# meadow

**A working nes starting point** (C (cc65)) - forked from the romdev `nes/platformer` example. It builds, runs, and renders RIGHT NOW, before you change a line.

This is SCAFFOLDING, not a finished game. The gameplay is deliberately thin - treat it as placeholder and make it yours. Its value is that the hard part is already done and working: the nes boot sequence, hardware init, and APIs are wired up correctly, so you evolve a running ROM instead of getting a long chain of fragile setup right from a blank file.

LEDGE LEAPER - side-scrolling platformer: gravity + Q4.4 sub-pixel jump physics, one-way platforms, pits and spikes, coins + distance scoring, battery hi-score. 2P is classic alternating turns (P2 on controller 2) with per-player score and lives. Sprite-0-hit split: fixed HUD over a seamlessly looping scrolling level.

## How to make it yours

Modify ONE thing at a time and re-run the build after each change - the working game is your regression oracle (it rendered before your edit; if it stops, your last edit broke it):

```js
build({
  output: "project",
  platform: "nes",
  path: "/tmp/meadow/proj",
  outputPath: "meadow.nes",
})
```

Use `output:"run"` to build + load + run + screenshot in one round trip. Don't start over in a blank file - retro bring-up is a chain of fragile hardware init with no partial credit; evolve this game instead, even into a very different game.

## Marker legend (read before restructuring anything)

- `/* ── HARDWARE IDIOM (load-bearing) ── */` - this code dodges a documented hardware footgun (the comment says which). **Reshape your gameplay around these regions**; if you must change one, read the cited TROUBLESHOOTING entry first. Each block's header lists what it needs (interrupt hooks, memory regions, register modes) - that's also what a transplant into another game must satisfy.
- `/* ── GAME LOGIC (clay) ── */` - enemy patterns, scoring, art, tuning. **Reshape freely** - this is where your game happens.

Need a technique this game doesn't have (another example does)? `examples({op:"show", example:"<platform>/<name>", technique:"..."})` extracts that example's marked block with its dependency header - graft it here instead of rewriting it.

## Files

- `main.c` - the game. Title screen, game loop, all the GAME LOGIC clay.
- `nes_runtime.h` - runtime library (rendering/input/sound helpers the game calls). Yours to extend; the HARDWARE IDIOM markers inside say which parts are load-bearing.
- `nes_runtime.c` - runtime library (rendering/input/sound helpers the game calls). Yours to extend; the HARDWARE IDIOM markers inside say which parts are load-bearing.
- `chr-ram-runtime.crt0.s` - startup code (reset vector, NMI handler, hardware vectors). **You own this.**
- `chr-ram-runtime.cfg` - ld65 linker config (memory layout, segment placement). **You own this.**

Every byte that compiles into your ROM is in this directory. If you move the repo somewhere else, you don't need to install anything from romdev to rebuild it - the compiler binaries are the only external dependency.

## cc65 is C89

Compiles **C89**, not C99/C11. Stick to:
- Declare loop variables at the top of blocks: `uint8_t i; for (i = 0; ...) { ... }`.
- All declarations at the top of every block - no mixed declarations + code.
- No designated initializers, no compound literals, no `//` line comments in some places.

<details>
<summary>Alternative: build from a hand-specified source manifest (when compiling edited loose source, not a project dir)</summary>

```js
build({
  output: "run",
  platform: "nes",
  sourcesPaths: {
    "main.c":         "main.c",
    "nes_runtime.c":  "nes_runtime.c",
    "_preset_crt0.s": "chr-ram-runtime.crt0.s",
  },
  includePaths: {
    "nes_runtime.h":  "nes_runtime.h",
  },
  linkerConfig: /* contents of chr-ram-runtime.cfg */,
  frames: 240,
})
```
</details>

## Inspecting + playtesting

- Byte level: `memory({op:"read"})`, `sprites({op:"inspect"})`, `palette({source:"live"})`, `background({view:"rendered"})`.
- No-vision render health: `frame({op:"verify"})` - "is the game actually rendering?" in one call.
- Human eyes: `playtest({op:"open"})` - a live window that follows your rebuilds; the emulator stays available to every other tool.
